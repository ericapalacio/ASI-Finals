const nodemailer = require('nodemailer');
const express = require('express');
const app = express();

email_address = 'eejpalacio@gmail.com'
message = 'Hello! This message is our prelim requirement :))'

var data = {
  Name: 'Erica Kurt Karl Jhules',
  Age: '18',
  Gender: 'FeMale',
  Address: 'Los Angeles City',
  Section: 'CS-401'
}


// Routing
app.get('/getName', function(req, res){
  res.status(200).send(data.Name);
});

app.get('/getAge', function(req, res){
  res.status(200).send(data.Age);
});

app.get('/getGender', function(req, res){
  res.status(200).send(data.Gender);
});

app.get('/getAddress', function(req, res){
  res.status(200).send(data.Address);
});

app.get('/getSection', function(req, res){
  res.status(200).send(data.Section);
});

app.listen(5000,function(err){
  if (err) console.log(err);
  console.log('Server listening on http://localhost:5000/getName/');
  console.log('Server listening on http://localhost:5000/getAge/');
  console.log('Server listening on http://localhost:5000/getGender/');
  console.log('Server listening on http://localhost:5000/getAddress/');
  console.log('Server listening on http://localhost:5000/getSection/');

});


//Nodemailer
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'akociikurt16@gmail.com',
    pass: 'jqiahseosdcvqhav',
  }
});

var mailOptions = {
  from: 'akociikurt16@gmail.com',
  to: email_address,
  text: message,
  }

app.post('/', function(req, res) {
  res.send(
    transporter.sendMail(mailOptions, function(error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log('Email sent: ' + info.response);
      }
    })
  );
})



