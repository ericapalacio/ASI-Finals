import React from "react";
import StartFirebase from "../firebaseConfig";
import {ref, set, get, update, remove, child} from "firebase/database";
import './index.css'

export class Crud extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            db: '',
            username:'',
            password:'',
            fullname:'',
            section:'',
        }
        this.interface = this.interface.bind(this);
    }

    componentDidMount(){
        this.setState({
            db: StartFirebase()
        });
    }

    render(){
        return(
            <>
                <h1>MIDTERM CRUD-USECASE</h1>
                <h1>_____________________________</h1>

                <label>Username</label>
                <input type = 'text' id = "userbox" value={this.state.username} onChange={e => {this.setState({username: e.target.value})}}/>
                <br></br>

                <label>Password</label>
                <input type = 'text' id = "passbox" value={this.state.password} onChange={e => {this.setState({password: e.target.value})}}/>
                <br></br>

                <label>Full name</label>
                <input type = 'text' id = "namebox" value={this.state.fullname} onChange={e => {this.setState({fullname: e.target.value})}}/>
                <br></br>

                <label>Student Number</label>
                <input type = 'text' id = "studnumbox" value={this.state.studentnumber} onChange={e => {this.setState({studentnumber: e.target.value})}}/>
                <br></br>
                <button id="signupBtn" onClick={this.interface}>Sign Up</button>

                <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
                <h1>MIDTERM CRUD-USECASE</h1>
                <h1>_____________________________</h1>
                <label>Username</label>
                <input type = 'text' id = "userbox" value={this.state.username} onChange={e => {this.setState({username: e.target.value})}}/>
                <br></br>

                <label>Password</label>
                <input type = 'text' id = "passbox" value={this.state.password} onChange={e => {this.setState({password: e.target.value})}}/>
                <br></br>
                <button id="loginBtn" onClick={this.interface}>Login</button>
                <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
                
                <h1>MIDTERM CRUD-USECASE</h1>
                <h1>_____________________________</h1>

                <label>Username</label>
                <input type = 'text' id = "userbox" value={this.state.username} onChange={e => {this.setState({username: e.target.value})}}/>
                <br></br>

                <label>Password</label>
                <input type = 'text' id = "passbox" value={this.state.password} onChange={e => {this.setState({password: e.target.value})}}/>
                <br></br>

                <label>Full name</label>
                <input type = 'text' id = "namebox" value={this.state.fullname} onChange={e => {this.setState({fullname: e.target.value})}}/>
                <br></br>

                <label>Student Number</label>
                <input type = 'text' id = "studnumbox" value={this.state.studentnumber} onChange={e => {this.setState({studentnumber: e.target.value})}}/>
                <br></br><br></br>
                <button id="updateBtn" onClick={this.interface}>Update</button>
                <button id="deleteBtn" onClick={this.interface}>Delete</button>
                <br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
            </>
        )
    }

    interface(event){
        const id = event.target.id;

        if(id=="signupBtn"){
            this.insertData();
        }
        else if(id=="loginBtn"){
            this.readData();
        }
        else if(id=="updateBtn"){
            this.updateData();
        }
        else if(id=="deleteBtn"){
            this.deleteData();
        }
    }

    getAllInputs(){
        return{
            username: this.state.username,
            password: this.state.password,
            fullname: this.state.fullname,
            studentnumber: this.state.studentnumber
        }
    }

    insertData(){
        const db = this.state.db;
        const data = this.getAllInputs();

        set(ref(db, 'user/'+data.username),
        {
            username: data.username,
            password: data.password,
            fullname: data.fullname,
            studentnumber: data.studentnumber
        })
        .then(()=>{alert('data was added successfully')})
        .catch((error)=>{alert('there was an error, details:'+error)});

        this.setState({
            username: '',
            password: '',
            fullname: '',
            studentnumber: ''
            })
    }

    updateData(){
        const db = this.state.db;
        const data = this.getAllInputs();

        set(ref(db, 'user/'+data.username),
        {
            username: data.username,
            password: data.password,
            fullname: data.fullname,
            studentnumber: data.studentnumber
        })
        .then(()=>{alert('data was updated successfully')})
        .catch((error)=>{alert('there was an error, details:'+error)});
    }

    deleteData(){
        const db = this.state.db;
        const data = this.getAllInputs();

        remove(ref(db, 'user/'+ data.username))
        .then(()=>{alert('data was deleted successfully')})
        .catch((error)=>{alert('there was an error, details:'+error)});

        this.setState({
            username: '',
            password: '',
            fullname: '',
            studentnumber: ''
            })
    }

    readData(){
        const dbref = ref(this.state.db);
        const data = this.getAllInputs();

        get(child(dbref,'user/'+data.username)).then((snapshot)=>{
            if(snapshot.exists()){
                let password = snapshot.val().password
                if(password == data.password){
                    this.setState({
                        username: snapshot.val().username,
                        password: snapshot.val().password,
                        fullname: snapshot.val().fullname,
                        studentnumber: snapshot.val().studentnumber
                        })
                        alert("Logged In")      
                }
            }else{
                alert("no data found!")
            }
        })
        .catch((error)=>{alert('there was an error, details:'+error)});
    }
   
}


