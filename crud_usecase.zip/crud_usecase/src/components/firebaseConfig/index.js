import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";


function StartFirebase(){
    const firebaseConfig = {
        apiKey: "AIzaSyAdxcED4ivStngt--nO-_Cuab-5mWGqGHA",
        authDomain: "midterm-crud-usecase.firebaseapp.com",
        databaseURL: "https://midterm-crud-usecase-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "midterm-crud-usecase",
        storageBucket: "midterm-crud-usecase.appspot.com",
        messagingSenderId: "920312519179",
        appId: "1:920312519179:web:338b12f45105a341e6c50e"
      };
      
      // Initialize Firebase
      const app = initializeApp(firebaseConfig);

      return getDatabase(app);

}
export default StartFirebase;