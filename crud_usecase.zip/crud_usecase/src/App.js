import {Crud} from './components/crud/index'
import './App.css';

function App() {
  return (
    <Crud/>
  );
}

export default App;
